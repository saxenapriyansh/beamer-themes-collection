# Side Scroller Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

An original side-scrolling platformer theme: blue sky with pixel clouds, a brick-and-grass ground strip, a score/coins/stage HUD, outlined pixel-style titles, a level-select course map for agendas, coin cards on brick platforms and a COURSE CLEAR closing slide with a checkered flag. It borrows no characters or items from any existing game.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeSideScroller.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{SideScroller}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Course map | `\coursemap{3}{Motivation,Method,Results,Discussion,Next steps}` (3 = current stage) |
| Coin card | `\coincard{1}{Text}` |
| Brick platform | `\platform{4.3}` (width in cm) |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| sky | `#5DB8F0 → #B4E2F8` |
| ink | `#1B1B2F` |
| brick / mortar | `#C0602F / #7A3418` |
| grass | `#5DBB46` |
| coin | `#F7C948` |
| red | `#C8402B` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
