# Neon Terminal Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A dark terminal-style Beamer theme in deep navy with cyan, pink and lime accents. It includes macOS-style code windows and a pixel "Snake game" python in Python's blue and yellow.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeNeonTerminal.sty` | The theme. |
| `pysnake.sty` | The pixel python macros (also used by the theme). |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** upload the zip (New Project → Upload Project). Set Menu → Compiler → **XeLaTeX** if it is not picked automatically.
* **Local:** `latexmk main.tex` or run `xelatex main.tex` twice. You need two runs so the footer snake knows the total slide count.
* pdfLaTeX also works, with fallback fonts.

## Fonts

The theme looks for fonts in this order and uses the first one it finds:

* **Text:** Inter → Fira Sans → default.
* **Code and titles:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed on your system → Fira Mono → DejaVu Sans Mono.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/>. Copy `JetBrainsMono-Regular.ttf`, `-Bold.ttf`, `-Italic.ttf` and `-BoldItalic.ttf` into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{NeonTerminal}          % [nosectionpages] [nocredit] [segments=16]
\windowtitle{~/talk -- zsh}
\promptline{~/slides}{make talk}
```

| Feature | How |
|---|---|
| Title slide (terminal window and snake) | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Breadcrumb above the title | `\framesubtitle{\breadcrumb{~/lecture-03}{cat notes.md}}` |
| Python code window | `\begin{terminal}{train.py} ... \end{terminal}`. The frame must be `[fragile]`. |
| Shell window | `\begin{shell}{zsh} ... \end{shell}`. The frame must be `[fragile]`. |
| LaTeX source window | `\begin{texwindow}{preamble.tex} ... \end{texwindow}`. The frame must be `[fragile]`. |
| Window for any content | `\begin{termwindow}{title} ... \end{termwindow}` |
| Tip box | `\tip{lr too high means divergence}` |
| Mono pill | `\tensortag{[64, 128]}` |
| Coloured words | `\cyan{}` `\pink{}` `\lime{}` `\amber{}` `\muted{}` |
| Block cursor | `\ntcursor` |
| Snake | `\pysnake[0.3]`, `\pysnakeline{8}`, `\pysnakeprogress` |

Section slides (`section_01 > Title` plus a snake) are added automatically for every `\section`. Use `[nosectionpages]` to turn them off.

The footer shows `short title :: section` on the left, and the growing snake with the slide counter (`[03 / 12]`) on the right. Set the short title with `\title[Short]{Long title}`. The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#0D1321` |
| panels | `#151E33` |
| text | `#E6EDF7` |
| cyan | `#22D3EE` |
| pink | `#F472B6` |
| lime | `#A3E635` |
| amber | `#FBBF24` |
| snake | `#FFD43B` / `#4B8BBE` |
