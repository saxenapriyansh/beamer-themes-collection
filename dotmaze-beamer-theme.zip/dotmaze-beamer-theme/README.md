# Dotmaze Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

An original maze-chase arcade theme: neon teal maze walls, rows of dots and glowing pellets, a small cyan robot collecting ideas and red bugs to avoid. The footer is a row of dots the robot eats as the talk progresses; corridor diagrams, pellet cards (key ideas) and bug cards (common mistakes) structure content. It uses none of any existing game's characters.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeDotmaze.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Dotmaze}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Corridor | `\corridor{3}` (number of pellets) |
| Pellet / bug cards | `\pelletcard{1}{Key idea}` · `\bugcard{Common mistake}` |
| Legend | `\mazelegend` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#07070F` |
| walls | `#22C3B0` |
| magenta | `#E040FB` |
| pellets | `#FFC93C` |
| dots | `#F5E6C8` |
| robot | `#38BDF8` |
| bugs | `#FF4D6D` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
