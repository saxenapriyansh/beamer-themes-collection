# Insert Coin Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A retro arcade theme: CRT scanlines, a score HUD across the top that climbs with every slide, levels for sections, boss fights for hard topics, power-ups for fixes, a high-score table and a GAME OVER closing slide. Neon green, magenta, cyan and yellow on black.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeInsertCoin.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{InsertCoin}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Boss card | `\boss{Overfitting}{70}{Description}` (HP in percent) |
| Power-up line | `\powerup[colour]{DROPOUT}` |
| High-score table | `\begin{hiscores} \scoreline{1ST}{NAME}{0.91} \end{hiscores}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#0A0A12` |
| text | `#E8E8F0` |
| neon green | `#39FF14` |
| magenta | `#FF3EA5` |
| cyan | `#22D3EE` |
| yellow | `#FFD43B` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
