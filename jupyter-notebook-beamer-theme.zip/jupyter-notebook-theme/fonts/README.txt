Optional: put IBM Plex Mono here for the exact look
(on Overleaf the TeX Live copy is usually found automatically).

Download (free, SIL Open Font License): https://github.com/IBM/plex/releases
Copy these files into this folder:
  IBMPlexMono-Regular.ttf
  IBMPlexMono-Bold.ttf
  IBMPlexMono-Italic.ttf
  IBMPlexMono-BoldItalic.ttf

Without them the theme falls back to DejaVu Sans Mono.
