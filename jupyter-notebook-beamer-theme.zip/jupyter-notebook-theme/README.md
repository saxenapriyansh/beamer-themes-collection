# Jupyter Notebook Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A light Beamer theme inspired by Jupyter notebooks. Slides use warm paper, `In [n]:` / `Out[n]:` cells, and Python blue with Jupyter orange. A pixel "Snake game" python in Python's blue and yellow ties it together.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeJupyterNotebook.sty` | The theme. |
| `pysnake.sty` | The pixel python macros (also used by the theme). |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the IBM Plex Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** upload the zip (New Project → Upload Project). Set Menu → Compiler → **XeLaTeX** if it is not picked automatically.
* **Local:** `latexmk main.tex` or run `xelatex main.tex` twice. You need two runs so the footer snake knows the total slide count.
* pdfLaTeX also works, with fallback fonts.

## Fonts

The theme looks for fonts in this order and uses the first one it finds:

* **Text:** Inter → Fira Sans → default.
* **Code and prompts:** `fonts/IBMPlexMono-*.ttf` → IBM Plex Mono installed on your system → IBM Plex Mono from TeX Live (`plex` package, available on Overleaf) → DejaVu Sans Mono.

For the exact look, download IBM Plex Mono (free, OFL) from <https://github.com/IBM/plex/releases> or Google Fonts. Copy `IBMPlexMono-Regular.ttf`, `-Bold.ttf`, `-Italic.ttf` and `-BoldItalic.ttf` into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{JupyterNotebook}           % [nosectionpages] [noheader] [nocredit] [segments=16]
\notebookname{applied_ai_ml.ipynb}
\kernelname{Python 3 (ipykernel)}
```

| Feature | How |
|---|---|
| Title slide (cells and snake) | `\titleframe` |
| Frame title | Automatic: `[n]: ## Title`, where n is the slide number |
| Code input cell | `\begin{incell}{8} ... \end{incell}`. The frame must be `[fragile]`. |
| Output cell | `\begin{outcell}{8} ... \end{outcell}` (plots, tables, text) |
| Markdown cell (selected, blue bar) | `\begin{mdcell}{7} ... \end{mdcell}` |
| Code-looking cell without verbatim | `\begin{codecell}{3} ... \end{codecell}` |
| LaTeX source cell | `\begin{texcell}{3} ... \end{texcell}`. The frame must be `[fragile]`. |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Grey shape pill | `\shape{(n, d)}` |
| Coloured words | `\blue{}` `\orange{}` `\muted{}` |
| Snake | `\pysnake[0.3]`, `\pysnakeline{8}`, `\pysnakeprogress` |

The In/Out labels sit in the left margin. Change their width with `\setlength{\nbgutter}{2cm}`, and widen `text margin left` to match if needed. Section slides (`# Section` cell plus a snake) are added automatically for every `\section`. Use `[nosectionpages]` to turn them off.

The footer shows `short title :: section` on the left, and the growing snake with the slide counter (`03 / 12`) on the right. Set the short title with `\title[Short]{Long title}`. The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| paper | `#F6F4EE` |
| code cell | `#ECEFF4` |
| ink | `#1E2330` |
| python blue | `#306998` |
| jupyter orange | `#E8743B` |
| keywords | `#2E7D32` |
| strings | `#BA2121` |
| snake | `#FFD43B` / `#306998` |
