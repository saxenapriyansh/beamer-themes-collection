# Chiselled Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

An original prehistoric cartoon theme: an orange sky with a smoking volcano and a huge carved stone slab on the title slide, sandstone content slides with faint ochre hand prints, lumpy stone tablets with carved icons, a cave-painting timeline, and a campfire cave for the closing slide. It uses no characters, names or catchphrases from any show.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeChiselled.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Chiselled}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Stone tablet | `\tablet{chisel}{STEP 1}{Text}` (icons: chisel, boulder, wheel, fire, hand) |
| Icon | `\stoneicon{fire}` |
| Cave timeline | `\cavetimeline{Fire,Wheel,Writing}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| sandstone | `#EBD3AE` |
| ink | `#3B2F27` |
| ochre | `#B5542D` |
| stone | `#B3A89B` |
| lava | `#E4572E` |
| leaf | `#6A994E` |
| sky | `#F2994A → #F9DDB4` |
| cave | `#3A2A20` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
