# Gridcell Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A light spreadsheet theme: a formula bar shows the current slide title as a formula, column letters and row numbers frame a soft cell grid, frame titles sit in a selected cell with a fill handle, and sheet tabs at the bottom name the current section. Cell highlights and comment cards make data-cleaning lectures easy.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeGridcell.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Gridcell}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Cell highlights | `\badcell{NaN}` · `\warncell{340}` · `\goodcell{ok}` (inside tables) |
| Comment card | `\cellnote{C3 · missing}{Text}` |
| Formula line | `\formula{=AVERAGE(B2:B6)}{35.0}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| sheet | `#FCFDFC` |
| text | `#1F2933` |
| sheet green | `#1E7145` |
| selection | `#DDEFE4` |
| bad cell | `#B42318 on #FDECEC` |
| warning cell | `#8A5A00 on #FFF4D6` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
