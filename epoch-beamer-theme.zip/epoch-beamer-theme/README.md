# Epoch Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A dark training-dashboard theme: the title slide shows a run status and a config card filled from your metadata, every footer is a training log with a progress bar, section slides save checkpoints, and metric and chart cards present results. Orange and teal on slate.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeEpoch.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Epoch}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Metric card | `\metric[colour]{label}{value}{trend}` |
| Chart card | `\begin{chartcard}{title} ... \end{chartcard}` |
| Run log | `\begin{runlog} \epochline{01}{0.912}{0.61} \end{runlog}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#12161C` |
| text | `#E6EAF0` |
| orange | `#FF9F43` |
| teal | `#2ED3B7` |
| red | `#FF5C7A` |
| panels | `#1A2029` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
