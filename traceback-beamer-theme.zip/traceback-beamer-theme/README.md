# Traceback Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A dark, teaching-first log theme: frame titles sit under a stack-trace breadcrumb, points are tagged INFO (concept), WARN (pitfall), ERROR (common bug) and FIX (remedy), and the closing slide exits with code 0. Blue, amber, red and green log levels on near-black.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeTraceback.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Traceback}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Level rows | `\loginfo{..}` · `\logwarn{..}` · `\logerror{..}` · `\logfix{..}` |
| Log stream | `\begin{logstream} \logline{WARN}{12:00:09}{message} \end{logstream}` |
| Traceback line | `\tracefile{train.py}{42}{fit}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#0B0D10` |
| text | `#D8DEE9` |
| INFO blue | `#5AA9F7` |
| WARN amber | `#F5B83D` |
| ERROR red | `#FF5C5C` |
| FIX green | `#7EE787` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
