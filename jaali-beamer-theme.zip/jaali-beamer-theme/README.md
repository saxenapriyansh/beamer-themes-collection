# Jaali Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A Mughal-geometry theme built only from patterns, with no monuments: a pointed arch frames the title against a sunrise, eight-point star tiles run along the base, content slides sit inside a double gold frame with corner rosettes, ideas live in arch-shaped niches with inlay flowers, and the closing slide glows on a deep teal lattice (jaali). Serif headings with teal, rose and gold.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeJaali.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Jaali}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Arch niche card | `\niche{Title}{Text}` |
| Inlay timeline | `\inlaytimeline{Collect,Clean,Model,Deploy}` |
| Decorations | `\inlayflower[1.5]` · `\ornament` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| ivory | `#FBF6EC` |
| ink | `#3A2A1E` |
| teal | `#1F6F6B` |
| rose | `#B5475E` |
| gold | `#C9A27E / #D9A441` |
| deep teal | `#134E4A` |
| sunrise | `#F4C3A1 → #FBF3E6` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
