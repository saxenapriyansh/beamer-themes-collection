# Stacked Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

An original falling-block puzzle theme: a well of stacked blocks with a glowing line clear on the title slide, a side HUD on every slide whose mini well fills up as the talk progresses, block-shaped icons for points, a LINE CLEAR card for takeaways and stacked-row diagrams for building concepts on foundations. Coral, yellow, mint and lavender on deep indigo.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeStacked.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Stacked}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Block icon | `\blockicon{T}{thAccent}` (shapes O, I, T, S, Z, L, J) |
| Block card | `\blockcard{O}{thSun}{Text}` |
| Takeaway card | `\clearrow{Text}` |
| Stacked rows | `\stackrows{Foundation,Middle,Top}` (bottom-up) |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#141428` |
| text | `#F5F5FA` |
| coral | `#FF6B6B` |
| yellow | `#FFD93D` |
| mint | `#4ECDC4` |
| lavender | `#A78BFA` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
