Optional: put JetBrains Mono here for the exact code font.

Download (free, SIL Open Font License): https://www.jetbrains.com/lp/mono/
Copy these files into this folder:
  JetBrainsMono-Regular.ttf
  JetBrainsMono-Bold.ttf
  JetBrainsMono-Italic.ttf
  JetBrainsMono-BoldItalic.ttf

Without them the theme falls back to Fira Mono or DejaVu Sans Mono.
