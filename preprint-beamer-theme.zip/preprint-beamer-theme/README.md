# Preprint Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A light academic theme for paper-reading sessions and research talks: serif type on cream paper, numbered section titles, an abstract set between rules, captioned figures, numbered equations and references, with a vertical preprint ID running up the left margin of every slide. Dark red and slate accents.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemePreprint.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Preprint}   % options: nosectionpages, nocredit
\preprintid{[preprint]~~talk~~\textperiodcentered~~2026}   % vertical margin ID
\preprintabstract{One-paragraph summary shown on the title slide.}
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Margin ID | `\preprintid{[preprint] talk · 2026}` |
| Title abstract | `\preprintabstract{One paragraph}` |
| Abstract box | `\begin{abstractbox} ... \end{abstractbox}` |
| Captions and references | `\figcaption{1}{Text}` · `\reference{[1] Author, Title, year.}` |
| Ornament rule | `\ornament` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| paper | `#FBF8F1` |
| ink | `#1F1B16` |
| dark red | `#9E2A2B` |
| slate blue | `#3B5E7E` |
| rules | `#D9D2C3` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
