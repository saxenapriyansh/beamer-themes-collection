# Tabline Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A dark code-editor theme: file tabs across the top follow your sections, line numbers run down a gutter, and a status bar at the bottom carries the branch, section and slide count. Purple, teal and coral syntax colours on a deep charcoal background.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeTabline.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Tabline}   % options: nosectionpages, nocredit
% the tab bar shows the current section name
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Editor panel | `\begin{panel}{TERMINAL} ... \end{panel}` |
| Terminal / output line | `\termline{pip install numpy}` · `\outputline{done}` |
| Problem lines | `\errline{..}` · `\warnline{..}` · `\infoline{..}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#1E1E2E` |
| text | `#CDD6F4` |
| purple | `#C792EA` |
| teal | `#89DDFF` |
| coral | `#F78C6C` |
| green | `#C3E88D` |
| panels | `#181825` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
