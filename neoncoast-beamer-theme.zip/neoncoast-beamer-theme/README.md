# Neon Coast Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

An original 80s Miami-sunset theme: a striped sun sinking into the sea between palm silhouettes, neon pink and cyan type, a glowing perspective grid floor on every slide, a 'now playing' footer that names the current section, neon cards with a soft glow and a highway timeline. It uses no logos, lettering or characters from any game.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeNeonCoast.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{NeonCoast}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Neon card | `\neoncard{01}{thAccent}{Text}` (colours: `thAccent` pink, `thAccentB` cyan, `thAccentC` yellow) |
| Highway timeline | `\highway{Collect,Clean,Model,Deploy}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| night | `#1A0B2E` |
| text | `#FFF4FA` |
| neon pink | `#FF4F9A` |
| cyan | `#2CE5F5` |
| sunset yellow | `#FFE45C` |
| magenta / peach | `#C2307A / #FF8A5B` |
| sea | `#0B2A3D` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
