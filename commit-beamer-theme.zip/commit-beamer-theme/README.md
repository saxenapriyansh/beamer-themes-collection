# Commit Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A light git-history theme: each frame title carries a commit hash, bullets are added lines, section slides check out a new branch, and the title slide shows a commit graph with a `git show` header and tag pills. Blue, purple and green branch colours on soft paper white.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeCommit.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Commit}   % options: nosectionpages, nocredit
\committags{talk,beamer,ml}   % pills on the title slide
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Title tags | `\committags{talk,beamer,ml}` |
| Git log box | `\begin{gitlog} \logentry{done}{a3f9c21}{intro} \end{gitlog}` (status: `done`, `head`, `todo`) |
| Graph styles | TikZ `commit` and `lane` styles, e.g. `\node[commit=thAccentB] at (1,0) {};` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#FAFAF7` |
| text | `#1F2328` |
| blue (main) | `#0969DA` |
| purple | `#8250DF` |
| green | `#1A7F37` |
| amber (hashes) | `#9A6700` |
| orange | `#E8743B` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
