# Tiles Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A flat, tile-based start-screen theme: thin oversized titles, a mosaic of solid colour tiles in mixed sizes on the title slide, a big numbered tile for each section, and a `\tile` macro for building your own tile layouts. Seven saturated tile colours on royal blue. No operating-system logos or names are used.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeTiles.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Tiles}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Tile | `\tile{4.45}{2.3}{thBlue}{play}{LABEL}{Body text}` (width, height in cm) |
| Tile colours | `thGreen` `thBlue` `thAmber` `thPurple` `thTeal` `thOrange` `thCrimson` `thDark` |
| Tile icons | `play` `code` `notes` `bars` `idea` `chat` `star` `clock` `none` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#1F3A93` |
| green | `#00A300` |
| blue | `#2D89EF` |
| amber | `#E3A21A` |
| purple | `#9F00A7` |
| teal | `#00ABA9` |
| orange | `#DA532C` |
| crimson | `#B91D47` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
