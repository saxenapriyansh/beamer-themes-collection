# Schematic Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A blueprint theme: white linework on grid paper inside a drawing border, an architect's title block on the title slide, sheet numbers in the footer, section-cut section slides, and TikZ styles for outlined boxes, dimension lines and numbered callouts. Made for architecture and pipeline diagrams.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeSchematic.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Schematic}   % options: nosectionpages, nocredit
% (no extra setup needed)
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Diagram styles | TikZ `bpbox`, `bphot` (highlighted), `bparrow`, `bpdash` |
| Dimension line | `\dimline{(0,0)}{(4,0)}{4 m}` inside a tikzpicture |
| Callout bubble | `\callout{1}` in text, or `\node[callout] {1};` in TikZ |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| blueprint | `#1F4E8C` |
| linework | `#EAF2FF` |
| labels | `#BFD4F2` |
| highlight | `#FFD43B` |
| grid minor / major | `#2A5C9C / #3C70B3` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
