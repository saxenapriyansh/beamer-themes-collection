# Backyard Build Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A sunny summer-cartoon theme: a sky, sun, fence and grass title slide with a sticker and a sticky note, sketchbook-grid content slides with marker-underlined titles, tilted build-part cards for pipelines, sticky notes, and a manila mission file with a TOP SECRET stamp. Bright orange, teal and yellow with chunky ink outlines.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeBackyardBuild.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{BackyardBuild}   % options: nosectionpages, nocredit
\projectlabel{PROJECT \#01}   % sticker on the title slide
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| Title sticker | `\projectlabel{PROJECT \#01}` |
| Build-part card | `\buildpart[-2]{thBlue}{PART 1}{Data hopper}` (angle, fill, label, name) |
| Arrow / sticky note | `\buildarrow` · `\sticky[-2]{Text}` |
| Mission file | `\begin{missionfile}{Title} \todo{..} \end{missionfile}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| paper | `#FFF8E7` |
| ink | `#20304A` |
| orange | `#E8642A` |
| teal | `#1E8A9A` |
| yellow / sticky | `#FFC93C / #FFE26A` |
| sky | `#3EC5E0 → #A6E6F2` |
| grass | `#5BBF5A` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
