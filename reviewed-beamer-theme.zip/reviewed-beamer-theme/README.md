# Reviewed Theme for Beamer

Theme by **Priyansh Saxena** · hi@priyanshsaxena.com

A light pull-request theme: the title slide is a PR header with an Open badge and passing checks, diffs show before/after code in red and green, review comments explain the change, and the closing slide is a Merged badge. Built for 'common mistakes' and code-walkthrough lectures.

## Files

| File | What it is |
|---|---|
| `main.tex` | Demo deck that documents every feature. Copy it to start a new talk. |
| `beamerthemeReviewed.sty` | The theme. |
| `latexmkrc` | Tells Overleaf/latexmk to use XeLaTeX. |
| `fonts/` | Optional: put the JetBrains Mono `.ttf` files here. |
| `main.pdf` | Compiled preview. |

## Compile

* **Overleaf:** New Project → Upload Project → choose the zip. If it is not picked automatically, set Menu → Compiler → **XeLaTeX**.
* **Local:** `latexmk main.tex`, or run `xelatex main.tex` twice (the slide counter needs two runs).
* pdfLaTeX also works, with fallback fonts.

## Fonts

* **Text:** Inter → Fira Sans → default sans.
* **Code:** `fonts/JetBrainsMono-*.ttf` → JetBrains Mono installed → Fira Mono → DejaVu Sans Mono.
* **Serif (where used):** TeX Gyre Pagella → Latin Modern.

For the exact look, download JetBrains Mono (free, OFL) from <https://www.jetbrains.com/lp/mono/> and copy the four `.ttf` files into `fonts/`.

## Using it

```latex
\documentclass[aspectratio=169,11pt]{beamer}
\usetheme{Reviewed}   % options: nosectionpages, nocredit
\prnumber{01}
\prchecks{Motivation is clear}{Results are reproducible}{Slides compile cleanly}
```

| Feature | How |
|---|---|
| Title slide | `\titleframe` |
| Closing slide | `\thanksframe{Questions?}{you@example.com}` |
| Code box (LaTeX) | `\begin{codebox}{file.tex} ... \end{codebox}` (frame must be `[fragile]`) |
| Code box (Python) | `\begin{pycode}{file.py} ... \end{pycode}` (frame must be `[fragile]`) |
| PR number and checks | `\prnumber{01}` · `\prchecks{..}{..}{..}` |
| Diff box | `\begin{diff}{file.py} \delline{old} \addline{new} \ctxline{same} \end{diff}` |
| Review comment | `\reviewcomment{Author}{Text}` |
| Status lines | `\approved{..}` · `\changesrequested{..}` · `\reviewitem{approved|changes|comment}{..}` |

Section slides are added automatically for every `\section`; `[nosectionpages]` turns them off.
The footer shows the short title and current section, and the slide counter (`03 / 12`). Set the short title with `\title[Short]{Long title}`.
The title slide carries a small theme credit; `[nocredit]` hides it.

## Palette

| Role | Hex |
|---|---|
| background | `#F6F8FA` |
| text | `#1F2328` |
| blue | `#0969DA` |
| green (added) | `#1A7F37` |
| red (removed) | `#CF222E` |
| purple (merged) | `#8250DF` |

---

This is an original design. It is not affiliated with or endorsed by any company, game, show or product it may evoke.
